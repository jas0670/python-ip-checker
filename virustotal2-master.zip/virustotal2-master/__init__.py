__author__ = "Philip Martin"
__copyright__ = "Copyright 2014, Philip Martin"
__credits__ = ["Philip Martin"]
__license__ = "MIT"
__version__ = "1.1"
__maintainer__ = "Philip Martin"
__email__ = "phillip.martin@gmail.com"
__status__ = "Production"